def confusion(num):
    if (num> 10):
        return(num-1)
    return confusion(confusion(num+5))   
print(confusion(2))     