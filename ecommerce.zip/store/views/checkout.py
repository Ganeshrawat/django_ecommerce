from django.shortcuts import render, HttpResponse, redirect
from store.models.product import product
from store.models.category import category
from store.models.customer import Customer
from django.views import View
from store.models.orders import Order
# from store.middlewares.auth import auth_middleware
# from django.utils.decorators import method_decorator


class CheckOut(View):  
    # @method_decorator(auth_middleware) 
    def post(self,request):
        address= request.POST.get('address')
        phone= request.POST.get('phone')
        customer= request.session.get('customer_id')
        cart= request.session.get('cart')
        Products= product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, Products)

        for Product in Products:
            order = Order(customer = Customer(id=customer),
                          products= Product,
                          price= Product.price,
                          address= address,
                          Phone= phone,
                          quantity= cart.get(str(Product.id))
                          )
        order.placeOrder()                   
        request.session['cart']= {}  
        return redirect("cart")



