from django.shortcuts import render, HttpResponse, redirect
from store.models.product import product
from store.models.category import category
from store.models.customer import Customer
from django.views import View


class cart(View):   
    def get(self,request):
        ids= (list(request.session.get('cart').keys()))
        products= product.get_products_by_id(ids)
        print(products)
        return render(request, 'cart.html', {'products': products})